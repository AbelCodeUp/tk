/**
 * jquery模块本地定义
 * @module jqueryDefine
 * @description   提供 jquery依赖注入定义
 * @author QiuShao
 * @date 2017/7/21
 */
import $ from 'jquery' ;
window.$ = $ ;
window.jQuery = $ ;
export default  $ ;